(window.webpackJsonp=window.webpackJsonp||[]).push([[253],{515:function(o){o.exports={hello:"Hello",hello2:"No language equivalent"}}}]);
//# sourceMappingURL=253.ca737981.chunk.js.map