(window.webpackJsonp=window.webpackJsonp||[]).push([[260],{522:function(e){e.exports={add:"Add",completed:"Completed",name:"Name"}}}]);
//# sourceMappingURL=260.4f00124b.chunk.js.map