(window.webpackJsonp=window.webpackJsonp||[]).push([[255],{513:function(o){o.exports={hello:"Hello",hello2:"No language equivalent"}}}]);
//# sourceMappingURL=255.97a8363d.chunk.js.map