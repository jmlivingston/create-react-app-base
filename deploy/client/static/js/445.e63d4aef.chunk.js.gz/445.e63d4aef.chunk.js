(window.webpackJsonp=window.webpackJsonp||[]).push([[445],{1014:function(o){o.exports={hello:"Hello",hello2:"No language equivalent"}}}]);
//# sourceMappingURL=445.e63d4aef.chunk.js.map