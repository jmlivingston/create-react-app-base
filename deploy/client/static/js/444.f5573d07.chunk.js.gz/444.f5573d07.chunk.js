(window.webpackJsonp=window.webpackJsonp||[]).push([[444],{1013:function(o){o.exports={hello:"\u3053\u306b\u3061\u308f"}}}]);
//# sourceMappingURL=444.f5573d07.chunk.js.map