(window.webpackJsonp=window.webpackJsonp||[]).push([[580],{1221:function(o){o.exports={hello:"\u3053\u306b\u3061\u308f"}}}]);
//# sourceMappingURL=580.1a135911.chunk.js.map