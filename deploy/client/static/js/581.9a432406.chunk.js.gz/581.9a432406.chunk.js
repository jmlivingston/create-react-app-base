(window.webpackJsonp=window.webpackJsonp||[]).push([[581],{1222:function(o){o.exports={hello:"Hello",hello2:"No language equivalent"}}}]);
//# sourceMappingURL=581.9a432406.chunk.js.map