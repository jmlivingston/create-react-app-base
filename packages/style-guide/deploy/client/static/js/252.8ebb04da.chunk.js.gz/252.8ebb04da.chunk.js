(window.webpackJsonp=window.webpackJsonp||[]).push([[252],{514:function(o){o.exports={hello:"\u3053\u306b\u3061\u308f"}}}]);
//# sourceMappingURL=252.8ebb04da.chunk.js.map