(window.webpackJsonp=window.webpackJsonp||[]).push([[254],{512:function(o){o.exports={hello:"\u3053\u306b\u3061\u308f"}}}]);
//# sourceMappingURL=254.8517a001.chunk.js.map